import fs from "node:fs";
import process from "node:process";
import { fileURLToPath } from "node:url";

// The output readers target this immutable TLC release. Resolve it from the
// installed skill, not the caller's working directory or a source checkout.
export const DEFAULT_TLC_JAR = fileURLToPath(new URL("../tools/tla2tools.jar", import.meta.url));
export const TLC_VERSION = "1.7.4";
export const TLC_SHA256 = "936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88";

const SET_TLC_VARS =
  "set TLA2TOOLS to the path of tla2tools.jar, and JAVA to a java binary (Java 11 or later).";
const indent = (text) => text.replace(/^/gm, "  ");

export function findTlc() {
  const { TLA2TOOLS, JAVA } = process.env;
  // A Java command name is resolved by the child process through PATH. Only
  // Java values containing a separator, and jar values, are filesystem paths.
  const javaPath = JAVA && /[\\/]/.test(JAVA) ? JAVA : "";
  for (const [name, file] of Object.entries({ JAVA: javaPath, TLA2TOOLS }))
    if (file && !fs.existsSync(file)) throw new Error(`${name} is ${file}, which does not exist.`);
  const jar = TLA2TOOLS || DEFAULT_TLC_JAR;
  if (!fs.existsSync(jar))
    throw new Error(`Cannot find bundled TLC at ${jar}. See RUNTIME.md, or ${SET_TLC_VARS}`);
  return { jar, java: JAVA || "java" };
}

export function cannotRunTlc({ java, jar }, r) {
  const said = `java exited ${r.status ?? r.signal}:\n${indent(`${r.stderr}${r.stdout}`.trim())}`;
  return `cannot run TLC with ${java} -cp ${jar}: ${r.error?.message ?? said}\nFix that, or ${SET_TLC_VARS}`;
}
