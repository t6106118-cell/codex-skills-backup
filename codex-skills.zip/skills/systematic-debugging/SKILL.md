---
name: systematic-debugging
description: Diagnose bugs, test failures, and unexpected behavior by reproducing the failure, tracing its cause, and verifying a focused fix.
---

# Systematic debugging

Find the cause before changing behavior. Start with the smallest useful
reproduction, and scale the investigation to the failure and its consequences.
Use existing project tools and checks.

## 1. Establish the failure

- Read the applicable project instructions and expected behavior. Identify the
  input, environment, observed result, and evidence for the expected result.
- Read complete relevant errors and exit statuses. Separate a product failure
  from a broken test expectation, environment problem, or inconsistent requirement.
- Reproduce the problem with an existing test or a small direct operation.
  Preserve the useful failing input. If it is intermittent, identify the sequence
  and failure signal rather than treating a successful rerun as a fix.
- Inspect recent relevant changes and configuration before proposing a cause.

## 2. Trace the cause

Trace the failing value or operation back to its owner. Compare it with a
working path and inspect the differences that could explain the result.

For a failure crossing component boundaries, inspect the relevant inputs,
outputs and configuration at those boundaries. Add targeted instrumentation
only where the available evidence cannot locate the failure. Keep credentials
and unrelated private data out of diagnostics.

Use [root-cause-tracing.md](root-cause-tracing.md) for a deeper backward trace.
An observed error identifies a boundary; it does not by itself prove a design
defect or justify a fallback.

## 3. Test one hypothesis

State a concrete cause and the observation that would support or reject it.
Use the cheapest discriminating check, changing one relevant condition at a time.

If the hypothesis fails, use the new evidence to revise it. Do not stack guesses,
repeat an unchanged failed approach, or hide the symptom with a catch, default,
retry or special case. Repeated failures are a reason to reconsider the causal
model and affected design assumptions.

Continue independent authorized work. Ask the user only for information or a
decision that materially affects the fix and cannot be resolved from evidence.

## 4. Fix and verify

- Apply the smallest complete correction at the responsible layer. Preserve
  required behavior and user data; remove structures made obsolete by the fix.
- When a cheap, meaningful regression test is available, follow the installed
  [tdd workflow](../tdd/SKILL.md) and demonstrate its failure before the fix.
  Otherwise use the closest real reproduction and explain any verification limit.
- Run the same failing case after the change, then the required project checks
  and adjacent checks justified by the change. Read actual output and exit status.
- Verify the artifact or state the task requires. A successful build, tool call,
  or agent summary does not establish unrelated behavior.
- Once the required checks pass, deliver. Broaden testing only for a new change,
  failure or unresolved material concern.

Report the cause, correction, checks actually run, and relevant remaining limits.
Reuse still-valid evidence; recheck it when changed inputs or state make it stale.

For timing-dependent failures, see
[condition-based-waiting.md](condition-based-waiting.md). Use
[defense-in-depth.md](defense-in-depth.md) when evidence shows that validation is
needed at more than one real boundary.
