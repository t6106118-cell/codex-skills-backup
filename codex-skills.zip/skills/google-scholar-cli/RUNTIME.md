# Build, install and use

This folder includes the complete modified CLI under [cli/](cli/README.md).
Cloning this repository is sufficient to obtain its source, tests and locked
build dependencies. No code from the original author's repository is fetched
when compiling this copy.

## Prerequisites

- Bun 1.4.4 for the verified build. The tested version is recorded in
  `cli/.bun-version`. Install that version using Bun's supported installation
  method; for example, `npm install --global bun@1.4.4` when Node/npm are available.
- Surf CLI, tested with 2.22.0, including its Chrome extension/native host and
  a connected browser profile. Follow the sibling [Surf runtime guide](../surf/RUNTIME.md)
  and verify with `surf doctor`.
- A Google session in that working Chrome profile for Scholar Labs. No university
  email is needed for normal search, citations or public PDFs.
- A PDF reader/extractor, such as the `pdf-inspector` skill, only when reading the
  downloaded documents. It is not a CLI compile-time dependency.

## Restore on Linux

If the entire skill folder was copied to the Codex skills directory, build
directly from its bundled `cli/` source and lockfile. A repository checkout is
not required. On a fresh installation with no existing `scholar` executable:

```bash
scholar_skill_dir="${CODEX_HOME:-$HOME/.codex}/skills/google-scholar-cli"
cd "$scholar_skill_dir/cli" &&
bun install --frozen-lockfile &&
bun run typecheck &&
bun run test &&
bun run build &&
mkdir -p "$HOME/.local/bin" &&
install -m 755 scholar "$HOME/.local/bin/scholar"
```

Inspect an existing `scholar` executable before replacing it, and preserve local
changes. Ensure `~/.local/bin` is on PATH. The compiled executable runs without
Bun; rebuilding needs Bun and the locked development dependencies. Copying the
skill does not transfer the separate executable or a working browser session.

Then, with Chrome and Surf running:

```bash
surf doctor
scholar auth
scholar lookup '"Attention Is All You Need"' --limit 3 --json
scholar lookup '"Attention Is All You Need"' --limit 1 --bibtex
```

`scholar auth` transfers the current browser session locally. Sessions are not
included in this repository, and restoring source does not restore a Google
login. A new machine needs its own authentication. Default tests use synthetic
responses; they do not require a Google account or call Scholar. Use `bun run test`
to isolate module mocks per file. Two optional journal-network checks are skipped
unless `SCHOLAR_LIVE=1` is set.

## Implemented changes

- Surf-based authentication and one bounded Labs session refresh replace the
  separate Chrome debugging-port route. `--port` is removed.
- Cookie handling respects host-only/domain scope, path and Secure. Citation and
  PDF redirects recompute scope at each hop. Flat Google cookies are used only
  as a fallback for HTTPS Scholar, not arbitrary download/citation hosts.
- Authentication preserves existing non-Google cookie records and private storage
  permissions (0700 directory, 0600 files). It does not harvest publisher sessions.
- Citation export preserves the fetched BibTeX; snippets are not labeled as abstracts.
- Journal/publisher parsing handles nonbreaking spaces in actual Scholar bylines.
- Unknown CLI flags fail explicitly, and storage tests use temporary directories.

## Verification and limitations

On Linux x64 on 2026-10-25, the original adapted installation passed 162 tests
and TypeScript checking. Live auth, Labs, classic lookup, journal filtering,
`cite`, and `lookup --bibtex` succeeded. Public arXiv and NeurIPS PDFs were
retrieved, and the latter's first page was read with separate PDF tooling.

This publication is additionally checked from an archive containing only the
committed source, using a frozen install, typecheck, tests, build and executable
smoke checks. Those checks establish rebuildability with the tested toolchain,
not indefinite compatibility with Google or all operating systems.

The site interfaces and journal `source:` operator are unofficial and may change.
Google can challenge the CLI even when the browser works; resolve challenges in
Chrome and do not retry in a loop. Actual paid institutional access is unverified.
A saved Scholar library-link ID is a resolver preference, not a subscription.

Result metadata may be truncated, and the aggregate result-count notice is
unreliable. `--limit` trims one returned batch; it does not paginate or bound
Labs' internal queries. Export citations and download files separately:
`--bibtex` returns before combined `--download` handling. Search downloads may
log individual failures while returning overall success; explicit `download`
calls and inspection of each PDF give clearer failure reporting.

See [cli/PROVENANCE.md](cli/PROVENANCE.md) for upstream attribution.
