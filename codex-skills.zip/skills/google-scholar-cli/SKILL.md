---
name: google-scholar-cli
description: Search Google Scholar with the installed scholar CLI, return structured paper metadata, restrict keyword searches by journal, export BibTeX, and retrieve linked PDFs. Use Surf-connected Chrome to refresh Scholar authentication or handle browser-only access. Use a PDF skill to read downloaded papers.
---

# Google Scholar CLI

Use `scholar` for structured Scholar queries and citation export. The locally adapted
build uses the working Chrome profile through Surf for authentication. See
[RUNTIME.md](RUNTIME.md) for building the bundled source, setup and limitations.

## Search and export

```bash
scholar lookup '"Attention Is All You Need"' --limit 3 --json
scholar lookup 'passive funds voting' --journal 'Journal of Corporation Law' --limit 3 --json
scholar search 'papers comparing transformer attention mechanisms' --limit 3 --json
scholar cite <clusterId> --json
scholar lookup '"Attention Is All You Need"' --limit 1 --bibtex > references.bib
scholar download 'https://arxiv.org/pdf/1706.03762' --output /explicit/path/paper.pdf
```

- `lookup` sends keywords/operators to classic Scholar. Prefer it for known titles,
  authors and journal restrictions. Repeated `--journal` flags combine with OR.
- `search` uses Scholar Labs to expand a natural-language question. It needs a
  signed-in Google session. It rejects `--journal`; use `lookup` for that filter.
- `--limit` trims the returned results; it does not paginate or limit the underlying
  Labs searches. Choose a small useful number and avoid repeated network probes.
- JSON records contain `title`, `authors`, `journal`, `year`, `publisher`, `snippet`,
  `url`, `pdfUrl`, `fullTextLinks`, `citations`, `clusterId`, and `position`.
  Metadata can be incomplete or truncated by Scholar. A search snippet is not a full
  abstract. Verify publication details against the paper when precision matters.
- `cite` and `--bibtex` return fetched citations unchanged. Use the `clusterId` from
  results, which may be alphanumeric. `--bibtex --json` returns `{clusterId,bibtex}`
  records, replacing the usual search metadata output.
- Run citation export and downloads as separate operations. In this build,
  `--bibtex` returns before `--download`; per-result download failures can appear on
  stderr while the overall search still succeeds. Prefer explicit `download` calls
  and verify each file when successful retrieval matters.
- The result-count notice on stderr is unreliable. Use the returned records; do not
  treat one page or a `--limit` sample as an exhaustive literature search.

## Authentication and recovery

If the snapshot is missing or stale, read the installed `surf` skill
and run:

```bash
surf doctor
scholar auth
```

`scholar auth` reuses an owned inactive Surf tab named `scholar-auth`, opens Scholar,
and saves Google/Scholar cookies and the matching browser identity. Chrome must be
open with Surf connected to the profile in which Scholar works. It does not require
a separate debugging port. A human may need to sign in or resolve a Google challenge.
The old `--port` authentication interface has been removed.

Labs automatically tries a Surf refresh once for a sign-in redirect or missing
session token, then retries once. An explicit `GOOGLE_SCHOLAR_COOKIES` override
prevents that refresh. For lookup/citation authentication failures, run `scholar auth`
and retry the requested operation once. CAPTCHA/rate limits require human resolution;
do not loop. If the usable browser page still works but the CLI remains blocked,
use Surf for the requested browser task and report the CLI limitation.

Exit codes: `69` browser/Surf unavailable, `75` detected challenge/rate limit, `77`
sign-in required on the auth/Labs paths, and `1` for other errors. Some endpoints
report an HTTP error as `1`; inspect stderr rather than assuming every block is `75`.

## PDFs and institutional links

Use the installed `surf` skill for publisher navigation or access tied to an interactive
browser session. Use the installed `pdf-inspector` skill to inspect downloaded
files or read their contents. Confirm the file is a PDF before claiming download
success; the CLI rejects HTML responses but does not validate every PDF payload.

The downloader sends saved cookies only to matching hosts/paths and respects Secure
cookies at redirects. Surf authentication refreshes Google/Scholar cookies only;
it preserves existing non-Google records but does not harvest publisher/proxy
sessions. Browser-only institutional authentication may therefore need Surf.
A saved Scholar library-link ID identifies a resolver preference, not a subscription.
Actual paid institutional access is unverified on this workstation. Open-access
search, citations and public PDFs do not require an institutional email address.

Session files under `~/.google-scholar` are private. Never print their contents or
include raw cookie exports in prompts, logs, reports or version control. The skill
and CLI run independently of the current working directory.
