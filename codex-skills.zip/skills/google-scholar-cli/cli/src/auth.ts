import { existsSync, readFileSync } from "node:fs";
import { mkdirSync, writeFileSync, renameSync, unlinkSync, chmodSync } from "node:fs";
import { COOKIES_FILE, BROWSER_COOKIES_FILE, CONFIG_DIR } from "./config.js";

export interface Cookies {
  [key: string]: string; // cookie name → value
}

export interface BrowserCookie {
  name: string;
  value: string;
  domain: string;
  path: string;
  secure: boolean;
}

/**
 * Resolve cookies using cascade: flag → env → dotfile
 */
export function resolveCookies(flagCookies?: string): Cookies {
  // 1. Flag override (JSON string)
  if (flagCookies) {
    try {
      return JSON.parse(flagCookies);
    } catch {
      throw new Error("Invalid cookie JSON in --cookies flag");
    }
  }

  // 2. Environment variable
  const envCookies = process.env.GOOGLE_SCHOLAR_COOKIES;
  if (envCookies) {
    try {
      return JSON.parse(envCookies);
    } catch {
      throw new Error("Invalid cookie JSON in GOOGLE_SCHOLAR_COOKIES env var");
    }
  }

  // 3. Dotfile
  if (existsSync(COOKIES_FILE)) {
    const content = readFileSync(COOKIES_FILE, "utf-8");
    try {
      return JSON.parse(content);
    } catch {
      throw new Error(
        `Corrupted cookie file at ${COOKIES_FILE}. Run 'scholar auth' to re-authenticate.`,
      );
    }
  }

  throw new Error("No cookies found. Run 'scholar auth' first.");
}

/**
 * Write a snapshot file atomically: a reader either sees the whole old file or
 * the whole new one. Two concurrent `search` runs can now self-heal at once,
 * and a torn write would leave a corrupt cookie file behind.
 */
export function writeFileAtomic(path: string, data: string): void {
  mkdirSync(CONFIG_DIR, { recursive: true, mode: 0o700 });
  chmodSync(CONFIG_DIR, 0o700);
  const tmp = `${path}.${process.pid}.tmp`;
  try {
    writeFileSync(tmp, data, { mode: 0o600 });
    renameSync(tmp, path);
  } catch (err) {
    try {
      unlinkSync(tmp);
    } catch {
      // tmp file may not exist; nothing to clean up
    }
    throw err;
  }
}

/**
 * Save cookies to dotfile with 0600 permissions.
 */
export function saveCookies(cookies: Cookies): void {
  writeFileAtomic(COOKIES_FILE, JSON.stringify(cookies, null, 2));
}

/**
 * Save all browser cookies (from all domains) to browser-cookies file.
 */
export function saveAllCookies(cookies: BrowserCookie[]): void {
  writeFileAtomic(BROWSER_COOKIES_FILE, JSON.stringify(cookies, null, 2));
}

/**
 * Load all browser cookies from the browser-cookies file.
 * Missing snapshots are empty; corrupt snapshots fail rather than erase cookies during refresh.
 */
export function resolveAllCookies(): BrowserCookie[] {
  if (existsSync(BROWSER_COOKIES_FILE)) {
    const content = readFileSync(BROWSER_COOKIES_FILE, "utf-8");
    try {
      return JSON.parse(content);
    } catch {
      throw new Error(`Corrupted cookie file at ${BROWSER_COOKIES_FILE}; repair it before refreshing the session.`);
    }
  }
  return [];
}

/**
 * Filter cookies that match a URL's domain and return as a Cookie header string.
 *
 * Domain matching follows browser conventions:
 * - ".google.com" matches "scholar.google.com" and "google.com"
 * - "google.com" matches exactly "google.com"
 */
export function cookiesForUrl(cookies: BrowserCookie[], url: string): string {
  const target = new URL(url);
  const hostname = target.hostname.toLowerCase();
  const matching = cookies.filter((c) => {
    if (c.secure && target.protocol !== "https:") return false;
    const cookiePath = c.path || "/";
    const pathMatches = target.pathname === cookiePath ||
      (target.pathname.startsWith(cookiePath) &&
        (cookiePath.endsWith("/") || target.pathname[cookiePath.length] === "/"));
    if (!pathMatches) return false;
    // Chrome distinguishes domain cookies by a leading dot; a host-only
    // cookie must not be broadened to every subdomain.
    const domain = c.domain.toLowerCase();
    const cookieHost = domain.replace(/^\./, "");
    return hostname === cookieHost ||
      (domain.startsWith(".") && hostname.endsWith(domain));
  });
  return matching.map((c) => `${c.name}=${c.value}`).join("; ");
}
