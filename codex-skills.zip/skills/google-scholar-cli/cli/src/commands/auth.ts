import { cookiesForUrl, writeFileAtomic, type BrowserCookie } from "../auth.js";
import { INST_FILE } from "../config.js";
import { userAgent } from "../identity.js";
import { exitCodeFor } from "../errors.js";
import { extractSurfSession, saveSurfSession } from "../surf.js";
import { printError } from "../output.js";

export async function cmdAuth(_args: string[], flags: { help: boolean }): Promise<number> {
  if (flags.help) {
    console.log(`scholar auth - Refresh session from Surf-connected Chrome

Usage: scholar auth

Uses an owned Surf tab named scholar-auth in your connected Chrome profile.
Sign in to Google in that profile first. Run 'surf doctor' if unavailable.
Saves Google/Scholar cookies and browser identity locally with private permissions.
Existing non-Google cookie records are preserved; other browser domains are not harvested.`);
    return 0;
  }
  try {
    const session = await extractSurfSession();
    saveSurfSession(session);
    console.log(`Saved ${Object.keys(session.googleCookies).length} Google session cookies and ${session.allBrowserCookies.length} scoped records through Surf.`);
    console.log(`Saved browser identity (${session.identity.platform}). Cookie values are not displayed.`);
    const instId = await extractInstId(session.googleCookies, session.allBrowserCookies);
    if (instId) {
      writeFileAtomic(INST_FILE, instId);
      console.log(`Saved Scholar library-link ID: ${instId} (not proof of subscription access).`);
    } else {
      console.log("No library-link ID detected. Institutional subscription access is unverified.");
    }
    return 0;
  } catch (err) {
    printError(err instanceof Error ? err.message : String(err));
    return exitCodeFor(err);
  }
}

/** Library-link preferences identify a resolver; they do not grant a subscription. */
export function institutionalIdFromHtml(html: string): string | null {
  for (const input of html.matchAll(/<input\b[^>]*>/gi)) {
    const tag = input[0];
    if (!/\bname=["']inst["']/i.test(tag) || !/\schecked(?:\s|=|>|\/)/i.test(tag)) continue;
    const value = tag.match(/\bvalue=["'](\d{2,})["']/i)?.[1];
    if (value) return value;
  }
  return null;
}

/**
 * Extract the institutional library ID (inst=<ID>) from Google Scholar.
 * Fetches the Scholar settings page using saved cookies,
 * looking for the inst= parameter that Scholar includes when library links
 * are configured.
 */
async function extractInstId(
  cookies: Record<string, string>,
  browserCookies: BrowserCookie[],
): Promise<string | null> {
  const url = "https://scholar.google.com/scholar_settings?hl=en";
  const cookieStr = cookiesForUrl(browserCookies, url) ||
    Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join("; ");
  const headers = { Cookie: cookieStr, "User-Agent": userAgent() };

  try {
    // Fetch the settings page which contains hidden form inputs with inst values.
    // Checked libraries have: <input name="inst" value="ID" checked> followed by a <label>
    const settingsResp = await fetch(
      url,
      { headers, redirect: "manual" },
    );
    if (!settingsResp.ok) return null;

    const html = await settingsResp.text();

    return institutionalIdFromHtml(html);
  } catch {
    return null;
  }
}
