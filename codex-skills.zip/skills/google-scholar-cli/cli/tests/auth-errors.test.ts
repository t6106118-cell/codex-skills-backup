import { describe, it, expect } from "bun:test";
import {
  AuthError,
  EXIT,
  browserUnreachable,
  notSignedIn,
  blocked,
  exitCodeFor,
} from "../src/errors.js";
import { MissingTokenError } from "../src/api/scholar.js";

describe("failure taxonomy", () => {
  it("uses sysexits codes", () => {
    expect(EXIT).toEqual({ OK: 0, UNAVAILABLE: 69, NOPERM: 77, TEMPFAIL: 75 });
  });

  it("browserUnreachable is UNAVAILABLE (69) and points at Surf diagnostics", () => {
    const err = browserUnreachable();
    expect(err).toBeInstanceOf(AuthError);
    expect(err.exitCode).toBe(EXIT.UNAVAILABLE);
    expect(err.message).toContain("surf doctor");
  });

  it("notSignedIn is NOPERM (77) and points at scholar auth", () => {
    const err = notSignedIn("Google Scholar");
    expect(err.exitCode).toBe(EXIT.NOPERM);
    expect(err.message).toContain("scholar auth");
  });

  it("blocked is TEMPFAIL (75)", () => {
    const err = blocked("Google Scholar");
    expect(err.exitCode).toBe(EXIT.TEMPFAIL);
    expect(err.message).toContain("Surf");
  });

  it("exitCodeFor maps AuthError to its code and everything else to 1", () => {
    expect(exitCodeFor(browserUnreachable())).toBe(69);
    expect(exitCodeFor(notSignedIn("x"))).toBe(77);
    expect(exitCodeFor(blocked("x"))).toBe(75);
    expect(exitCodeFor(new Error("boom"))).toBe(1);
    expect(exitCodeFor("not even an error")).toBe(1);
  });

  it("keeps a layout change at exit 1 — never conflated with NOPERM", () => {
    const err = new MissingTokenError("layout changed");
    expect(err).not.toBeInstanceOf(AuthError);
    expect(exitCodeFor(err)).toBe(1);
    expect(exitCodeFor(err)).not.toBe(EXIT.NOPERM);
  });
});
