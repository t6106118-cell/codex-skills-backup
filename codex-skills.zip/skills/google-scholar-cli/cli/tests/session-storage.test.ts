import { afterAll, expect, it, mock } from "bun:test";
import { mkdtempSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const scratch = mkdtempSync(join(tmpdir(), "scholar-storage-"));
const config = join(scratch, ".google-scholar");
mock.module("../src/config.js", () => ({
  CONFIG_DIR: config, COOKIES_FILE: join(config, "cookies"),
  BROWSER_COOKIES_FILE: join(config, "browser-cookies"), UA_FILE: join(config, "ua"),
}));
afterAll(() => rmSync(scratch, { recursive: true, force: true }));
const { saveAllCookies, resolveAllCookies, resolveCookies } = await import("../src/auth.js");
const { saveSurfSession } = await import("../src/surf.js");

it("refreshes Google snapshots, preserves publisher cookies and uses private permissions", () => {
  const publisher = { name: "library", value: "synthetic", domain: "proxy.example.edu", path: "/", secure: true };
  const old = { name: "SID", value: "old-synthetic", domain: ".google.com", path: "/", secure: true };
  const fresh = { ...old, value: "new-synthetic" };
  saveAllCookies([old, publisher]);
  saveSurfSession({ googleCookies: { SID: fresh.value }, allBrowserCookies: [fresh], identity: { userAgent: "Test/1", platform: "Linux", brands: "" } });
  expect(resolveAllCookies()).toEqual([publisher, fresh]);
  const override = process.env.GOOGLE_SCHOLAR_COOKIES;
  delete process.env.GOOGLE_SCHOLAR_COOKIES;
  try { expect(resolveCookies()).toEqual({ SID: fresh.value }); }
  finally { if (override !== undefined) process.env.GOOGLE_SCHOLAR_COOKIES = override; }
  expect(statSync(config).mode & 0o777).toBe(0o700);
  for (const name of ["cookies", "browser-cookies", "ua"]) {
    expect(statSync(join(config, name)).mode & 0o777).toBe(0o600);
  }
});

it("does not silently replace a corrupt scoped-cookie snapshot", () => {
  writeFileSync(join(config, "browser-cookies"), "invalid synthetic json");
  expect(() => resolveAllCookies()).toThrow("Corrupted cookie file");
});
