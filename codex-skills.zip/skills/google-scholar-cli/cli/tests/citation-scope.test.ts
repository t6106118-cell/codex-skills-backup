import { afterEach, expect, it } from "bun:test";
import { fetchBibtex } from "../src/api/scholar.js";

const realFetch = globalThis.fetch;
afterEach(() => { globalThis.fetch = realFetch; });

it("keeps Google cookies off the BibTeX host and its redirects; preserves raw citation", async () => {
  const calls: Array<{ url: string; cookie: string | null }> = [];
  const raw = "@article{test, title={A real title}, year={2026}}\n";
  globalThis.fetch = (async (input, init) => {
    const url = String(input);
    calls.push({ url, cookie: new Headers(init?.headers).get("cookie") });
    if (calls.length === 1) return new Response('<a class="gs_citi" href="https://scholar.googleusercontent.com/scholar.bib">BibTeX</a>');
    if (calls.length === 2) return new Response(null, { status: 302, headers: { location: "https://example.org/citation.bib" } });
    return new Response(raw);
  }) as typeof fetch;
  expect(await fetchBibtex("test", { SID: "synthetic-secret" }, [])).toBe(raw);
  expect(calls).toHaveLength(3);
  expect(calls[0].cookie).toContain("SID=synthetic-secret");
  expect(calls[1].cookie).toBeNull();
  expect(calls[2].cookie).toBeNull();
});
