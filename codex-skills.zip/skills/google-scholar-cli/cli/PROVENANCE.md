# Source provenance

- Original project: https://github.com/edwinhu/google-scholar-cli
- Original author/project owner: edwinhu
- Base tag: v0.2.0
- Base commit: `1b8f38fc8cfb2edb122615676ce341b86b6607eb`
- Adaptation published in: https://github.com/t6106118-cell/snowman0379
- The base README is preserved as [UPSTREAM.md](UPSTREAM.md) for attribution and
  historical reference; its CDP setup instructions describe the original build.

The `src/` and `tests/` directories contain the adapted implementation and tests.
The original project's `.claude` notes and automated release workflow are not
needed to build this copy and are not included. All runtime source, compiler
configuration and locked package metadata needed to compile this version are
included. Original Git history and prebuilt executables are not included.

No LICENSE file or explicit license declaration was present in the base project
files inspected. This import does not add a license declaration on behalf of the
original author. Attribution here does not imply endorsement by that author.
