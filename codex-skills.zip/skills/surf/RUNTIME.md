# Surf runtime provisioning

Copying this skill folder only supplies instructions. Surf also needs the CLI,
a supported browser extension, and a native messaging host. It does not need a
registered MCP server. Install or repair these components when requested; do
not change a working browser setup merely because the skill is used.

On the recorded Fedora workstation, Node.js/npm and Surf CLI 2.22.0 were used
with Chrome. For a fresh Linux account, install a compatible Node.js and npm,
then install the version matched to these instructions into a user-local prefix:

```bash
npm install --global --prefix "$HOME/.local" surf-cli@2.22.0
"$HOME/.local/bin/surf" --version
"$HOME/.local/bin/surf" extension-path
```

Put `~/.local/bin` on PATH. Before replacing an existing installation or host
manifest, inspect it and preserve local customizations. In Chrome, open
`chrome://extensions`, enable Developer mode, and load the unpacked extension
from the path printed by `surf extension-path`. Copy its extension ID, then run
`surf install <extension-id>` with that actual ID, restart Chrome, and reload
the extension. On Linux Chrome this registers the native messaging host; see
[Surf's installation instructions](https://github.com/nicobailon/surf-cli#installation)
for other browsers and operating systems.

With the browser running, verify the connection with `surf doctor` and
`surf tab.list`. Authentication to services used through Surf is separate:
a copied skill or CLI installation does not restore browser sign-ins. The
`google-scholar-cli` and `deep-x-research` skills depend on this browser
connection for their Surf-based workflows.
