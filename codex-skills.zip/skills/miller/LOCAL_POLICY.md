# Miller direct-shell policy

When Codex uses Miller (`mlr`) directly through the shell for agent-generated
data inspection, transformation, validation, or exploratory analysis, prefer:

    mlr --no-shell ...

unless the task genuinely requires Miller to invoke an external command.

Do not persistently set `MLR_NO_SHELL=1`; keep the restriction command-scoped
so legitimate user-requested `system()`, `exec()`, or `--prepipe` workflows
remain available.

Before allowing Miller shell-outs, require a concrete task need rather than
using them as an implementation convenience.

Treat `which` results as ranked candidates. Its `confident` field means a
name matched the query, not that the top candidate performs the requested
operation. Check the candidate's purpose and options with `list_capabilities`
before running it. For example, sorting fields within each record does not
sort the records by a field's value.

Keep the upstream Miller playbook text intact; put local operating guidance
and corrections in this file. A short installation-routing footer in
`SKILL.md` may point to [RUNTIME.md](RUNTIME.md), which owns binary installation,
MCP registration and fresh-machine verification.
