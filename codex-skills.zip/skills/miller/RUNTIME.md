# Runtime provisioning

This file documents the Miller runtime used by the `miller` skill. Keep data
workflow instructions in `SKILL.md`. Keep `LOCAL_POLICY.md` as a separate,
authoritative local policy layer; do not merge it into either file.

## Source and installed state

- Upstream: `https://github.com/johnkerl/miller`
- Version verified on this workstation on 2026-10-29: upstream release 6.21.0.
- Package: official `miller-6.21.0-linux-amd64.rpm`, installed as RPM
  `miller-6.21.0-1.x86_64`.
- Executable: `/usr/bin/mlr`, a stripped static x86-64 ELF.
- Installed binary SHA-256:
  `dc6692d37d7e42faeda7b09cf0861b7cd757f6c538072d95590a9c2aec9ed63a`.
- Release RPM SHA-256:
  `a169accdd615215ffd1b6b92aa7995c1853259493752b5559d9fde5a348750ba`.

The RPM is upstream-produced, not a Fedora build: its release is `1`, its
packager is John Kerl, and it is unsigned. Verify the downloaded digest before
installing and record that trust decision.

## Runtime modes

Miller 6.21.0 provides both the ordinary CLI and an MCP stdio server:

```text
mlr <flags> <verb> ...
mlr mcp [--allow-shell] [--timeout SECONDS] [--max-output-bytes N]
```

`mlr mcp` exposes `list_capabilities`, `which`, `validate_dsl`,
`describe_data`, and `run`, plus the Miller playbook prompt/resource. By
default its subprocesses set `MLR_NO_SHELL=1` and `MLR_ERRORS_JSON=1`, which
disables DSL `system`/`exec`, piped redirects, and `--prepipe` while returning
structured errors. A blocked DSL `system()` can instead produce an `(error)`
field while `run` reports exit code 0, so inspect returned values as well as
the exit status. The skill's normal workflow uses this structured MCP surface;
when installing it for that workflow, register the server as described below.
Direct CLI use remains available if the user requests a CLI-only setup.

Direct shell use remains valid. Follow the included `LOCAL_POLICY.md`: use
`mlr --no-shell ...` for agent-generated inspection or transformation unless
a concrete user requirement needs Miller to invoke an external command. Do
not persist `MLR_NO_SHELL=1`, and do not change or publish away this local
policy layer.

## Install

On Fedora x86-64, download the pinned official RPM and verify it before the
local package transaction:

```bash
curl --fail --location --output /tmp/miller-6.21.0-linux-amd64.rpm \
  https://github.com/johnkerl/miller/releases/download/v6.21.0/miller-6.21.0-linux-amd64.rpm &&
printf '%s  %s\n' \
  a169accdd615215ffd1b6b92aa7995c1853259493752b5559d9fde5a348750ba \
  /tmp/miller-6.21.0-linux-amd64.rpm | sha256sum --check &&
sudo dnf install /tmp/miller-6.21.0-linux-amd64.rpm
```

Use the asset matching the target architecture. Do not add an external package
repository for this standalone RPM. If a maintained distribution package is
used instead, verify that it provides the required 6.21-era `mlr mcp` surface.

## Register Miller in Codex

Copying the `miller` skill folder into `~/.codex/skills/` makes its instructions
available, but does not install the `mlr` binary or register its MCP server.
Keep `SKILL.md`, this `RUNTIME.md`, and `LOCAL_POLICY.md` together. After
installing Miller, register its server for the Codex app and CLI when the user
wants the skill's normal structured-tool workflow.

Use the same Codex home as the desktop app: normally `~/.codex/config.toml`.
If `CODEX_HOME` is configured, check the app and CLI environments. If they use
different homes, register the server in each intended home separately. Running
the app-bundled executable in a terminal uses that terminal's environment; it
does not automatically inherit the running app's home. The following uses the
app-bundled executable on the Fedora installation described above; if it is
elsewhere, locate the installed app binary or use the standalone `codex`
command with the intended Codex home.

First inspect any existing registration:

```bash
/usr/lib/chatgpt/resources/codex mcp get miller --json
```

If it is already registered, inspect its command, arguments and enabled state;
preserve user customizations. If the command reports that `miller` is absent,
and the installed `mlr` executable is `/usr/bin/mlr`, add it:

```bash
/usr/lib/chatgpt/resources/codex mcp add miller -- /usr/bin/mlr mcp
```

For other errors, diagnose the error before adding anything. If `mlr` is
installed elsewhere, use its actual absolute path. The equivalent entry in the
same Codex home's `config.toml` is:

```toml
[mcp_servers.miller]
command = "/usr/bin/mlr"
args = ["mcp"]
```

Use the CLI command or edit the TOML entry, not both. Do not create a duplicate
table or overwrite an existing server blindly. Do not add `--allow-shell` or
persist `MLR_NO_SHELL=1`; the MCP server already disables shell-outs for its
subprocesses by default. Its `run` tool can still write files. The desktop app
and CLI use the same registration when they use the same Codex home. See
[OpenAI's MCP setup guide](https://learn.chatgpt.com/docs/extend/mcp).

Check the saved entry with `mcp get miller --json` using the same Codex
executable. In the desktop app, use **Settings → MCP servers → Restart** as
needed, then start a new chat and check that the Miller tools are exposed.
Do not interrupt an active app session merely to refresh it. A listed entry
confirms configuration, not successful server startup or tool exposure.

## Verify

```bash
type -a mlr
mlr --version
mlr mcp --help
printf 'name,value\na,1\nb,2\n' | \
  mlr --no-shell --icsv --ojson sort -f value
```

Expect version 6.21.0 for the pinned installation, the five MCP tool names in
`mlr mcp --help`, and two ordered JSON records. If using another version,
verify its actual version and required tool surface instead.

For an MCP registration, initialize the server and confirm `tools/list` exposes
`list_capabilities`, `which`, `validate_dsl`, `describe_data`, and `run`. In a
client that exposes the tools, use a small temporary CSV fixture and check:

- `validate_dsl` with `{"kind":"put","expression":"$double = $value * 2"}`
  returns `valid: true`.
- `describe_data` with `{"files":["/absolute/path/to/fixture.csv"],"input_format":"csv"}`
  returns the fixture's actual field names and values. Replace the placeholder.
- `run` with `{"args":["--icsv","--ojson","sort","-f","value"],"stdin_text":"name,value\nb,2\na,1\n"}`
  returns exit code 0 and JSON records ordered `a`, then `b`.
- A harmless `run` test using `--prepipe` is rejected without running a shell.
  Inspect both returned values and errors: blocked DSL `system()` can produce
  an `(error)` field even when the reported exit code is 0.

If the client does not expose the tools, resolve server startup or session
refresh before claiming the integration works. Remove the temporary fixture
when finished.

## Upgrade or rebuild

Review upstream release notes and official asset digests. Upgrade only to a
version that preserves or deliberately changes the CLI, MCP tools, structured
errors, and shell-isolation behavior expected by the skill. Install the new
RPM, rerun direct and MCP checks, and confirm `LOCAL_POLICY.md` remains separate
and unchanged. Record the new package metadata, asset and binary hashes, path,
tool catalog/schema version, and behavior in this file and the inventory.
