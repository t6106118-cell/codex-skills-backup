# Firecrawl adapter runtime provisioning

The `fetch-url-markdown` skill uses two local HTML adapter commands. Copying the
skill folder supplies their source and lockfiles, but does not
install the executables. They are ordinary CLI programs, not MCP servers.
Native Markdown and document handoff routes do not require these adapters.

## Source and dependencies

| Command | Bundled source | Pinned upstream library |
|---|---|---|
| `firecrawl-html-to-markdown` | [adapters/html-to-markdown](adapters/html-to-markdown) | [firecrawl/html-to-markdown](https://github.com/firecrawl/html-to-markdown), commit `1af9901a5d6101621120204f7ea3f5355fd5ea31` |
| `firecrawl-html-extractor` | [adapters/html-extractor](adapters/html-extractor) | [firecrawl/html-extractor](https://github.com/firecrawl/html-extractor), commit `0a2b7432a20e356c2254f17e1b0acb2e79d88917` |

Use these bundled projects and dependency locks to build the commands. The
adapter checks exercise URL resolution, embedded data URLs, GFM tables,
main-content extraction, JSON metadata, invalid inputs, output failures, and
the skill's conversion caller. Current installed paths and binary hashes are
recorded in the workstation inventory.

## Command interfaces

```text
firecrawl-html-to-markdown [--url URL] [FILE|-]
firecrawl-html-extractor [--url URL] [--text|--json] [--metadata] [FILE|-]
```

Both read one file, `-`, or stdin and write to stdout. The Go adapter applies
the upstream GitHub-Flavored Markdown plugin; its optional base URL resolves
relative links and leaves `data:` URLs unchanged. The Rust adapter normally
emits main-content Markdown; `--json` includes page type, quality and fallback
status, and `--metadata` writes those fields to stderr. `--text` and `--json`
are mutually exclusive. The skill uses only Markdown.

Output write and flush errors fail the command. The adapter checks include a
Linux `/dev/full` regression for single-line output as well as normal conversions.

At the pinned extractor revision, plain text can be absent, inline text can be
misordered, relative links can remain unresolved, listing links can be
discarded, and page chrome can remain. Clean extraction must stay explicit.

## Restore on a fresh Linux account

Install Go, stable Rust/Cargo, a C linker, Git, Python 3 and HTTPS CA
certificates. The builds and tests were run on Fedora 44 x86-64
with Go 1.26.10 and rustc/Cargo 1.99.0. Older toolchains or other platforms
are not yet verified. The locked first build also needs network access to the
Go module proxy and the Git/Cargo dependency sources.

The example below assumes both commands are absent from `~/.local/bin`. It
builds and checks temporary candidates before installing them there; it stops
if either destination exists, including a symlink. Ensure `~/.local/bin` is on
PATH. For an existing installation, inspect the commands and local
customizations before deliberately updating them.

```bash
(
  set -eu
  skill_dir="${CODEX_HOME:-$HOME/.codex}/skills/fetch-url-markdown"
  build_dir="$(mktemp -d)"
  trap 'rm -rf -- "$build_dir"' EXIT
  mkdir -p "$build_dir/bin" "$HOME/.local/bin"
  for name in firecrawl-html-to-markdown firecrawl-html-extractor; do
    if [ -e "$HOME/.local/bin/$name" ] || [ -L "$HOME/.local/bin/$name" ]; then
      printf 'Inspect the existing command before replacing it: %s\n' "$HOME/.local/bin/$name" >&2
      exit 1
    fi
  done
  (
    cd "$skill_dir/adapters/html-to-markdown"
    CGO_ENABLED=0 go build -mod=readonly -trimpath \
      -o "$build_dir/bin/firecrawl-html-to-markdown" .
  )
  cargo build --release --locked \
    --manifest-path "$skill_dir/adapters/html-extractor/Cargo.toml" \
    --target-dir "$build_dir/rust-target"
  install -m 0755 "$build_dir/rust-target/release/firecrawl-html-extractor" \
    "$build_dir/bin/firecrawl-html-extractor"
  python3 "$skill_dir/adapters/test_adapters.py" "$build_dir/bin"
  install -m 0755 "$build_dir/bin/firecrawl-html-to-markdown" "$HOME/.local/bin/"
  install -m 0755 "$build_dir/bin/firecrawl-html-extractor" "$HOME/.local/bin/"
)
```

For a public-page workflow, separately verify an appropriate known URL with
the skill's `--expect` and `--min-chars` options. Browser mode additionally
requires a supported local Chromium browser. PDF and office routes depend on
their respective skills. No fresh Fedora installation or live browser-mode
fetch was exercised by the 2026-10-29 adapter check.

## Upgrade

For a new upstream version, inspect each repository, update one pinned
dependency at a time, regenerate and retain its lockfile, build and run the
adapter checks, and compare required behavior with the current commands. Switch
the active installation only after verification; remove superseded installation
roots after the replacement is verified. Preserve local customizations and
update this guide and the workstation inventory with relevant changes.
