// Command firecrawl-html-to-markdown adapts Firecrawl's Go library for the
// fetch-url-markdown skill.
package main

import (
	"flag"
	"fmt"
	"io"
	"net/url"
	"os"

	"github.com/PuerkitoBio/goquery"
	md "github.com/firecrawl/html-to-markdown"
	"github.com/firecrawl/html-to-markdown/plugin"
)

func run() int {
	flags := flag.NewFlagSet("firecrawl-html-to-markdown", flag.ContinueOnError)
	flags.SetOutput(os.Stderr)
	flags.Usage = func() {
		fmt.Fprintln(os.Stderr, "usage: firecrawl-html-to-markdown [--url URL] [FILE|-]")
	}
	baseArg := flags.String("url", "", "base URL for relative links")
	if err := flags.Parse(os.Args[1:]); err != nil {
		if err == flag.ErrHelp {
			return 0
		}
		return 2
	}
	if flags.NArg() > 1 {
		flags.Usage()
		return 2
	}
	var base *url.URL
	if *baseArg != "" {
		parsed, err := url.Parse(*baseArg)
		if err != nil || !parsed.IsAbs() || parsed.Host == "" {
			fmt.Fprintf(os.Stderr, "firecrawl-html-to-markdown: --url must be an absolute URL: %q\n", *baseArg)
			return 1
		}
		base = parsed
	}
	var input io.Reader = os.Stdin
	if flags.NArg() == 1 && flags.Arg(0) != "-" {
		file, err := os.Open(flags.Arg(0))
		if err != nil {
			fmt.Fprintln(os.Stderr, "firecrawl-html-to-markdown:", err)
			return 1
		}
		defer file.Close()
		input = file
	}
	options := &md.Options{GetAbsoluteURL: func(_ *goquery.Selection, raw, _ string) string {
		if base == nil {
			return raw
		}
		reference, err := url.Parse(raw)
		if err != nil || reference.Scheme == "data" {
			return raw
		}
		return base.ResolveReference(reference).String()
	}}
	converter := md.NewConverter("", true, options)
	converter.Use(plugin.GitHubFlavored())
	output, err := converter.ConvertReader(input)
	if err != nil {
		fmt.Fprintln(os.Stderr, "firecrawl-html-to-markdown:", err)
		return 1
	}
	if _, err := output.WriteTo(os.Stdout); err != nil {
		fmt.Fprintln(os.Stderr, "firecrawl-html-to-markdown:", err)
		return 1
	}
	return 0
}

func main() { os.Exit(run()) }
